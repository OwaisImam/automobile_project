<!-- footer -->
<footer class="footer">
	<div class="container">
		<div class="row">
			<div class="footbar col-lg-3 col-md-6 col-12">
				<div class="widget">
					<h6 class="footer-links mb-4">
						About Us
					</h6>
					<div class="about-data">
						<p class="m-0">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
					</div>
				</div>
			</div>
			<div class="footbar col-lg-3 col-md-6 col-12 mt-4 mt-md-0">
				<div class="widget">
					<h6 class="footer-links mb-4">
						Useful Links
					</h6>
					<ul class="quick-links">
						<li>
							<a href="#">Buy Now</a>
						</li>
						<li>
							<a href="#">Book Now</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="footbar col-lg-3 col-md-6 col-12 mt-4 mt-md-5 mt-lg-0">
				<div class="widget">
					<h6 class="footer-links mb-4">
						Other Links
					</h6>
					<ul class="quick-links">
						<li>
							<a href="#">Electronics</a>
						</li>
						<li>
							<a href="#">Fashion</a>
						</li>
						<li>
							<a href="#">Toys</a>
						</li>
					</ul>
				</div>
			</div>
	        <div class="footbar col-lg-3 col-md-6 col-12 mt-4 mt-md-5 mt-lg-0">
	        	<div class="widget">
					<h6 class="footer-links mb-4">
						Privacy
					</h6>
					<ul class="quick-links">
						<li>
							<a href="#">Privacy Policy</a>
						</li>
						<li>
							<a href="#">Terms & Condition</a>
						</li>
						<li>
							<a href="#">Cookies</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>

	</footer>
	 <!-- End footer -->
<div class="copyright-bottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <p class="copyright m-0 text-center text-black">
                    Copyright © 2021.All Rights Reserved.
                </p>
            </div>
        </div>
    </div>
</div>
    

