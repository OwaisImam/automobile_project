<!-- Favicon -->
<link rel="shortcut icon" type="image/icon" href="#">
<!-- Main structure css file -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/customer/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/customer/style.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/customer/responsive.css">
<!-- owl carousel -->  
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/customer/owl-carousel-min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/customer/owl-theme-default-min.css">
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
<!-- Favicon -->
<link rel="shortcut icon" type="image/icon" href="#">
<!-- Main structure css file -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/customer/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/customer/style.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/customer/responsive.css">
<!-- owl carousel -->  
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/customer/owl-carousel-min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/customer/owl-theme-default-min.css">
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

<script src="<?php echo base_url();?>assets/js/customer/jquery.js"></script>
<script src="<?php echo base_url();?>assets/js/customer/popper.js"></script>
<script src="<?php echo base_url();?>assets/js/customer/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/customer/owl-carousel.js"></script>
<script src="<?php echo base_url();?>assets/js/customer/main.js"></script>
<script src="<?php echo base_url();?>assets/js/customer/font-awesome-5-pro.js"></script>
