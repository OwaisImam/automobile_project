
<body>
<?php $this->load->view('customer/scripts'); ?>
<?php $this->load->view('customer/header'); ?>

<?php $this->load->view('customer/chat_window'); ?>

</body>

<?php $this->load->view('customer/footer'); ?>